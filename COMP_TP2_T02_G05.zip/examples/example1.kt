fun main (){
    val a = 2 + 2
    val b: Int = 3
    val k: Boolean = true
    var x = 1
    //var z: Float = 2.1
    x = x + 2
    //z++
    //var o: Float = readln()
    print(x)
}