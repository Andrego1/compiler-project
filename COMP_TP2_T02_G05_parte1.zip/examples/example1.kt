fun main (){
    val a = 2
    val b: Int = 3
    var x = 1
    var z: Float = 2.1
    print("Exemplos: $a $b $x $z")
}