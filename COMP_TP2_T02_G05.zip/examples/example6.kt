fun main (){
    var sucess = true
    if (sucess) sucess = false else sucess = true
    
    /*
    //sdiwbidbw
    nvfewoincvownocv
    isqbin
    fun main (){}
     */
    //print("hello")
    val i = 0
    //var t: Boolean //TEMOS DE ACEITAR ESTE !
    var t = true
    if (i > 10){
        t = false
    } else {
        t = true
    }

    var k = 2
    if (k >= 0){
        k++
    } else {
        print(k)
    }
    print(t)
}