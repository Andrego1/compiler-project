fun main() {
    val s: String = readln()
    print(s)
}