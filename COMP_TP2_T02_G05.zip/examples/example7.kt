fun main(){
    var i: Int = 1
    if (i+1 == 3){
        return
    } else {
        i += 1
    }
    print(i)
}