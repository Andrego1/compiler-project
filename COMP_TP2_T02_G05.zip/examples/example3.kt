fun main () {
    val a   = true
    print(a)

    val b   = false
    print(b)

    val and = a && b
    print(and)

    val or  = b || a
    print(or)

    val not = !b
    print(not)
}