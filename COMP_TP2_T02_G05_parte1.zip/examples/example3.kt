fun main () {
    val a   = true
    val b   = false
    val and = a && b
    val or  = b || a
    val not = !b
    print("$a $b $and $or $not")
}