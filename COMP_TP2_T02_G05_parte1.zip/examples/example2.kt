fun main () {
    val a = 1+2
    val b = 1*3
    val c = 10/2
    val d = 10-5
    val e = 10%2
    print("Sum: $a, Product: $b, Quotient: $c, Difference: $d, Mod: $e")
}