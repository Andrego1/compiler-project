fun main() {
    val s: Int = readln()
    print(s)
}