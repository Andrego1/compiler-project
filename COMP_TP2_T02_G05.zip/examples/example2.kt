fun main () {
    val a = 1+2
    val b = 1*3
    val c = 10/2
    val d = 10-5
    val e = 10%2
    print(a)
    print(b)
    print(c)
    print(d)
    print(e)
}