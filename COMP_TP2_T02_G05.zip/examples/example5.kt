fun main(){
    var i = 0
    var a = 1 > 2
    if ( a ){
        i = i + 1
    } else {
        i = i - 1
    }
    print(i) // novo
}